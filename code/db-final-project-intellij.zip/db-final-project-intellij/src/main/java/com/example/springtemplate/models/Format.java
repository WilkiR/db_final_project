package com.example.springtemplate.models;

public enum Format {
    GIF,
    LOCATION,
    PHOTO,
    TEXT,
    VIDEO
}
